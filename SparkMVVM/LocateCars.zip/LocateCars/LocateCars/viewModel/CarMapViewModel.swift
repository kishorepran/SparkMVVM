//
//  CarMapViewModel.swift
//  LocateCars
//
//  Created by Pran Kishore on 9/3/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit
import MapKit

class CarMapViewModel: NSObject {
    
    var annotations : [CarAnnotation]?
    
    init(annotations : [CarAnnotation]?) {
        super.init()
        self.annotations = annotations
    }
    
    // MARK: - Handle Zoom settings
    let regionRadius: CLLocationDistance = 3000
    
    //Default to zoom into one of the pins.
    var dafaultRegion : MKCoordinateRegion? {
        guard let initialLocation = annotations?.first?.coordinate else {return nil}
        return region(for: initialLocation)
    }
    
    func region(for coordinate: CLLocationCoordinate2D) -> MKCoordinateRegion {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(coordinate,regionRadius, regionRadius)
        return coordinateRegion
    }
    
    func allAnnotation(except: CarAnnotation) -> [CarAnnotation]? {
        guard let items = annotations else {return nil}
            let toHide = items.filter { (item) -> Bool in
                return item.vin != except.vin
            }
        return toHide
    }
}
