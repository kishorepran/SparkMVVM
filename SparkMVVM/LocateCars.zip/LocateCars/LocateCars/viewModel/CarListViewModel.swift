//
//  CarListViewModel.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit

//Implementing Delegate pattern for communication between view controller and view model
protocol ViewModelDelegate : class {
    func viewModelDidUpdate()
    func viewModelUpdateFailed(error : WUError)
}

class CarListViewModel: NSObject {

    weak var delegate : ViewModelDelegate?
    let dataManager = CarListDataManager()
    
    var carPlacemarks : [CarPlacemark]? {
        didSet {
            delegate?.viewModelDidUpdate()
        }
    }
    
    //Web service call
    func getCarList(forced updateNeeded: Bool = false) {
        
        //Check for local data if not forced update
        if let item = LocalStorageModel.shared.loadLocalCarInfo() , updateNeeded == false {
            carPlacemarks = item.placemarks
            return
        }
        
        dataManager.carList(success: { (data) in
            let decoder = JSONDecoder()
            do {
                let item = try decoder.decode(CarInfo.self, from: data)
                self.carPlacemarks = item.placemarks
                LocalStorageModel.shared.update(carInfo: item)
            } catch {
                self.delegate?.viewModelUpdateFailed(error: WUServerResponseError.JsonParsing)
                print(error)
            }
        }) { (error) in
            self.delegate?.viewModelUpdateFailed(error: error)
            print(error)
        }
    }
}
