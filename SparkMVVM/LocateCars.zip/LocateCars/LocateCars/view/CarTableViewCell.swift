//
//  CarTableViewCell.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit

class CarTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName : UILabel!
    @IBOutlet weak var lblDecoration : UILabel!
    @IBOutlet weak var lblVin : UILabel!
    @IBOutlet weak var lblAddress : UILabel!
}
