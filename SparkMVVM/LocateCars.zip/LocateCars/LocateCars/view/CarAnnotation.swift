//
//  CarAnnotation.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit
import MapKit

class CarAnnotation: NSObject, MKAnnotation {
    let title: String?
    let locationName: String
    let vin: String
    let coordinate: CLLocationCoordinate2D
    
    init(title: String, locationName: String, vin: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.locationName = locationName
        self.vin = vin
        self.coordinate = coordinate
        
        super.init()
    }
    
    var subtitle: String? {
        return locationName
    }
}
