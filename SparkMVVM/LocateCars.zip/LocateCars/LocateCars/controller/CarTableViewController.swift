//
//  CarTableViewController.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit
import JGProgressHUD

class CarTableViewController: UITableViewController {

    private let cellIdentifier = "carTableViewCell"
    private let viewModel = CarListViewModel()
    private let hud = JGProgressHUD(style: .dark)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        let rightBarButton = UIBarButtonItem.init(title: "In Map", style: .plain, target: self, action:#selector(showMap))
        self.navigationItem.rightBarButtonItem = rightBarButton
        title = "Car List"
        viewModel.delegate = self
        setupRefreshControl()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let items = viewModel.carPlacemarks, items.count > 0 {return}
        //Progress
        hud.show(in: self.view, animated: true)
        viewModel.getCarList()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    private func setupRefreshControl () {
        // Configure Refresh Control
        guard let refreshControl = tableView.refreshControl else {return}
        refreshControl.addTarget(self, action: #selector(refreshCarInfo(_:)), for: .valueChanged)
        let color = UIColor.init(named: "CarGreen") ?? UIColor.orange
        refreshControl.tintColor = color
        refreshControl.attributedTitle = NSAttributedString(string: "Fetching car List ...", attributes: [NSAttributedStringKey.foregroundColor : color])
    }
    
    @objc private func refreshCarInfo(_ sender: Any) {
        // Fetch Car list forced
        viewModel.getCarList(forced: true)
    }
    // MARK: - UI Button action
    @objc private func showMap() {
        performSegue(withIdentifier: "presentMap", sender: viewModel)
    }
    
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return viewModel.carPlacemarks?.count ?? 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        
        if let car = viewModel.carPlacemarks?[indexPath.row], let carCell = cell as? CarTableViewCell {
            carCell.lblName.text = car.name
            carCell.lblVin.text = car.vin
            carCell.lblDecoration.text = "Decoration: Interior :: \(car.interior) :: Exterior :: \(car.exterior)"
            carCell.lblAddress.text = car.address
        }
        return cell
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if let destinationVC = segue.destination as? CarMapViewController , let item  = sender as? CarListViewModel  {
            let items = item.carPlacemarks?.compactMap({$0.mapAnnotation})
            destinationVC.viewModel = CarMapViewModel.init(annotations: items)
        }
    }
}

// MARK: - ViewModelDelegate
extension CarTableViewController : ViewModelDelegate {
    
    func viewModelDidUpdate() {
        //Progress
        hud.dismiss()
        tableView.reloadData()
        stopRefeshControl()
    }
    
    func viewModelUpdateFailed(error: WUError) {
        //Progress
        hud.dismiss()
        stopRefeshControl()
        showAlert(for: error)
    }
    
    func stopRefeshControl () {
        //Check if we launched via referesh control.
        if let control = tableView.refreshControl , control.isRefreshing {
            control.endRefreshing()
        }
    }
    
}
