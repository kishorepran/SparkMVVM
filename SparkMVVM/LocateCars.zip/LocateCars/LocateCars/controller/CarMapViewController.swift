//
//  CarMapViewController.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit
import MapKit
class CarMapViewController: UIViewController {

    let clusterCarAnnotationIdentifier = "ClusterCarAnnotationIdentifier"
    let carAnnotationIdentifier = "CarAnnotationIdentifier"
    let clusterCarIdentifier = "ClusterCarIdentifier"
    
    var viewModel : CarMapViewModel!
    @IBOutlet weak var mapView : MKMapView!
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        mapView.delegate = self
        mapView.register(CarClusterAnnotation.self, forAnnotationViewWithReuseIdentifier: clusterCarAnnotationIdentifier)
        let rightBarButton = MKUserTrackingBarButtonItem.init(mapView: mapView)
        self.navigationItem.rightBarButtonItem = rightBarButton
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showUserLocation()
        if let items = viewModel.annotations {
            mapView.addAnnotations(items)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setPreffredMapRegion()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        locationService.stopUpdates()
    }

    // MARK: - UserLocation Management
    let locationService = LocationService.shared
    
    // MARK: - Set the preffered Map region
    private func setPreffredMapRegion(){
        //Check for default region we must have one
        guard var region = viewModel.dafaultRegion else {return}
        //Check in case we have user location
        if let location = locationService.currentLocation {
            region = viewModel.region(for: location.coordinate)
        }
        mapView.setRegion(region, animated: true)
    }
    
    private func showUserLocation() {
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            mapView.showsUserLocation = true
            locationService.startUpdates()
        }
    }
    
    // MARK: - Memory
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CarMapViewController: MKMapViewDelegate {
    // MARK: - MKMapView Annotations delegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if let clusterAnnotation = annotation as? MKClusterAnnotation {
            let clusterAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier:clusterCarAnnotationIdentifier, for : clusterAnnotation)
            clusterAnnotationView.displayPriority = .required
            return clusterAnnotationView
        } else if let _ = annotation as? CarAnnotation {
            var view: MKMarkerAnnotationView
            if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: carAnnotationIdentifier) as? MKMarkerAnnotationView {
                dequeuedView.annotation = annotation
                view = dequeuedView
            } else {
                view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: carAnnotationIdentifier)
            }
            view.displayPriority = .required
            view.clusteringIdentifier = clusterCarIdentifier
            return view
        } else {
            //Let system handle the default case.
            return nil
        }
    }
    
    // MARK: - MKMapView Annotations Selection delegate
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        if let annotation = view.annotation as? CarAnnotation, let toHide = viewModel.allAnnotation(except: annotation) {
            mapView.removeAnnotations(toHide)
        }
    }
    // MARK: - MKMapView Annotations DeSelection delegate
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        if let annotation = view.annotation as? CarAnnotation, let toShow = viewModel.allAnnotation(except: annotation) {
            mapView.addAnnotations(toShow)
        }
    }
}

