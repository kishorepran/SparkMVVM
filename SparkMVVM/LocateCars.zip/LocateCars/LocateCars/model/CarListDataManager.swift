//
//  CarListDataManager.swift
//  LocateCars
//
//  Created by Pran Kishore on 9/3/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import Foundation

public class CarListRouter : APIRouter {
    override var path : String {
        return "locations.json"
    }
}

class CarListDataManager: NSObject {
    public func carList(success:@escaping (Data) -> Void, failure:@escaping (WUError) -> Void) {
        let router = CarListRouter()
        WUService.request(router, success: success, failure: failure)
    }
}
