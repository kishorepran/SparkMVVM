//
//  CarClusterAnnotation.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/28/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import UIKit
import MapKit

class CarClusterAnnotation: MKAnnotationView {
    
    struct ClusterAnnotationViewConstants {
        static let width: CGFloat = 36
        static let height: CGFloat = 36
    }
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        displayPriority = .required
        collisionMode = .circle
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var annotation: MKAnnotation? {
        willSet {
            if let cluster = newValue as? MKClusterAnnotation {
                // Get the car annotations count
                let carAnnotations = cluster.memberAnnotations.compactMap({
                    return $0 as? CarAnnotation
                })
                let count = carAnnotations.count
                image = image(for: count)
            }
        }
    }
    
    private func image(for count : Int) ->  UIImage? {
        // Render the image we will use for the cluster annotation.
        // It will be a circle containing the number of car annotations clustered
        let size = CGSize(width: ClusterAnnotationViewConstants.width,
                          height: ClusterAnnotationViewConstants.height)
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }
        context.setFillColor(UIColor.darkGray.cgColor)
        UIBezierPath(ovalIn: CGRect(x: 0,
                                    y: 0,
                                    width: ClusterAnnotationViewConstants.width,
                                    height: ClusterAnnotationViewConstants.height)
            ).fill()
        
        let attributes = [ NSAttributedStringKey.foregroundColor: UIColor.white,
                           NSAttributedStringKey.font: UIFont.systemFont(ofSize: 12)]
        let text = "\(count)"
        let textSize = text.size(withAttributes: attributes)
        let rect = CGRect(x: ClusterAnnotationViewConstants.width / 2 - textSize.width / 2,
                          y: ClusterAnnotationViewConstants.height / 2 - textSize.height / 2,
                          width: textSize.width,
                          height: textSize.height)
        text.draw(in: rect, withAttributes: attributes)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
}
