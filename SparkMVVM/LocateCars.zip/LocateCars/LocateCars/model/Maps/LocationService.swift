//
//  LocationService.swift
//  LocateCars
//
//  Created by Pran Kishore on 9/3/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import MapKit
import Foundation

class LocationService: NSObject {
    
    let distanceFilter = 50
    
    // MARK: Instance
    public static let shared = LocationService()
    private override init() {
        manager = CLLocationManager()
        super.init()
        //Request authorization
        if CLLocationManager.authorizationStatus() == .notDetermined {
            manager.requestWhenInUseAuthorization()
        }
        // The accuracy of the location data
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        // The minimum distance (measured in meters) a device must move horizontally before an update event is generated.
        manager.distanceFilter = CLLocationDistance(distanceFilter)
        manager.delegate = self
    }
    
    // MARK: Properties
    private let manager: CLLocationManager
    /// The last known location, this is updated when a new location is retrieved or set to nil when location is not available.
    public var currentLocation: CLLocation?
    
    public func startUpdates () {
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }
    
    public func stopUpdates () {
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            manager.stopUpdatingLocation()
        }
    }
}

extension LocationService : CLLocationManagerDelegate {
    
    /// indicates whether the app is currently running in simulator
    var isRunningInSimulator: Bool {
        return TARGET_OS_SIMULATOR != 0
    }
    
    public func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {
            return
        }
        // singleton for get last(current) location
        currentLocation = location
    }
    
    public func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // do on error
        let error = error as NSError
        // If location is not set in the simulator then we need to stop the updating
        let simulatorCondition = isRunningInSimulator && error.code == CLError.locationUnknown.rawValue
        // We don't have to stop the location updating if the location is unavailable
        let deviceCondition = !isRunningInSimulator && error.code == CLError.denied.rawValue
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse && (simulatorCondition || deviceCondition) {
            manager.stopUpdatingLocation()
        }
        currentLocation = nil
    }
}
