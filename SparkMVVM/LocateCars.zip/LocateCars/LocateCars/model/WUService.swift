//
//  WUService.swift
//  LocateCars
//
//  Created by Pran Kishore on 9/3/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import Alamofire
import Foundation

struct APIConstants {
    static let baseURL = "https://s3-us-west-2.amazonaws.com/wunderbucket/"
}

protocol APIConfiguration: URLRequestConvertible {
    var method: HTTPMethod { get }
    var path: String { get }
    var parameters: Parameters? { get }
}

public class APIRouter : APIConfiguration {
    
    let method : HTTPMethod = .get
    var path : String {
        return "locations.json"
    }
    
    var parameters : Parameters?
    
    init(_ params : Parameters? = nil ) {
        parameters = params
    }
    
    public func asURLRequest() throws -> URLRequest {
        let url = try APIConstants.baseURL.asURL()
        var request = URLRequest(url: url.appendingPathComponent(path))
        request.httpMethod = method.rawValue
        request.timeoutInterval = TimeInterval(60)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        return try URLEncoding.default.encode(request, with: parameters)
    }
}

class WUService: NSObject {
    static func request(_ request: URLRequestConvertible, success:@escaping (Data) -> Void, failure:@escaping (WUError) -> Void){
        #if DEBUG
        let sample = try? request.asURLRequest()
        print("Response for \(String(describing: sample?.url))")
        if let test = sample?.httpBody ,let params = String.init(data:test, encoding: .utf8) {
            print("Params \(params)")
        }
        #endif
        //Response data is used as we don't want to parse data twice. i.e. once in Alamofire and one in codable class.
        Alamofire.request(request).responseData { (responseObject) -> Void in
            if let data = responseObject.data , responseObject.result.isSuccess {
                #if DEBUG
                let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments)
                print(json.debugDescription)
                #endif
                success(data)
            }
            if responseObject.result.isFailure {
                var item : WUError
                if let error = responseObject.result.error as NSError? {
                    //Known error.
                    item = WUServiceError.init(error: error)
                } else {
                    //Other failures
                    item = WUServiceError.init(errorCode: WUServiceError.ErrorCode.unknownError)
                }
                failure(item)
            }
        }
    }
}
