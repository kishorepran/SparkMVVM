//
//  CarInfo.swift
//  LocateCars
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import Foundation
import MapKit

class CarInfo: Codable {
    let placemarks: [CarPlacemark]
}

struct CarPlacemark: Codable {
    
    let address: String
    let coordinates: [Double]
    let engineType: EngineType
    let exterior: Terior
    let fuel: Int
    let interior: Terior
    let name, vin: String
    
    enum CodingKeys: String, CodingKey {
        case address
        case coordinates
        case engineType
        case exterior
        case fuel
        case interior
        case name
        case vin
    }
    
    var location : CLLocation? {
        let lat = coordinates[1]
        let long = coordinates[0]
        let ordinates = CLLocation(latitude: lat, longitude: long)
        return ordinates
    }
    
    var mapAnnotation : CarAnnotation? {
        guard let ordinates = location else {return nil}
        let annotation = CarAnnotation.init(title: name, locationName: address, vin: vin, coordinate: ordinates.coordinate)
        return annotation
    }
}

enum EngineType: String, Codable {
    case ce = "CE"
}

enum Terior: String, Codable {
    case good = "GOOD"
    case unacceptable = "UNACCEPTABLE"
}
