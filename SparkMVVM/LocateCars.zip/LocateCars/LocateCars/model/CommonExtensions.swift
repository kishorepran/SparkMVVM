//
//  CommonExtensions.swift
//  LocateCars
//
//  Created by Pran Kishore on 9/3/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    /**
     Show Error alert with a title and message. Does not have any thing in completion. Stays on the view controller that is being called.
     
     - Parameter error: Type of error that could be displayed to user.
     */
    func showAlert(for error:WUError) {
        showErrorAlert(error.localizedTitle, message:error.localizedMessage)
    }
    /**
     Show Error alert with a title and message. Does not have any thing in completion. Stays on the view controller that is being called.
     
     - Parameter title: Title of the alert. Defaults to "Wunder"
     - Parameter message: Message to be displayed to user
     */
    func showErrorAlert(_ title:String?, message:String) {
        
        let text : String = title ?? "Wunder"
        let alertController = UIAlertController(title: text, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (result : UIAlertAction) -> Void in
            
        }
        
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func showErrorAlert(_ message:String) {
        showErrorAlert(nil, message: message)
    }
}
