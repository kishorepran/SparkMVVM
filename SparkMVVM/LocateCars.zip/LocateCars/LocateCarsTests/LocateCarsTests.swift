//
//  LocateCarsTests.swift
//  LocateCarsTests
//
//  Created by Pran Kishore on 8/27/18.
//  Copyright © 2018 Pran Kishore. All rights reserved.
//

import XCTest
@testable import LocateCars

class LocateCarsTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testJsonParsing() {
        // Simple unit test to check JSON Parsing.
        let viewModel = CarListViewModel()
        viewModel.prepareCarList()
        XCTAssert(viewModel.carPlacemarks != nil)
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}

//For Mocking JSON response
extension CarListViewModel {
    
    //Returns data from a given JSON file file stored locally.
    var localJsonData : Data? {
        guard let jsonPath = Bundle.main.path(forResource: "locations", ofType: "json") else { return nil }
        let data = NSData.init(contentsOfFile: jsonPath) as Data?
        return data
    }
    
    //Parse JSON data as it would be recieved from server.
    func prepareCarList() {
        let decoder = JSONDecoder()
        do {
            let item = try decoder.decode(CarInfo.self, from: localJsonData!)
            carPlacemarks = item.placemarks
        } catch  {
            print(error)
        }
    }
}
